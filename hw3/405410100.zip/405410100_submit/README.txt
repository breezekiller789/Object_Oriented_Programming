1 .
    There is a tag file in current folder, it is good for code tracing in vim,

    if want to look up the function definition, just type in :tag <function_name>
    
    also can use tab to autocomplete function name.
